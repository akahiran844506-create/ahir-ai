package com.ahir.ai

import android.app.Application
import android.content.Context
import androidx.appcompat.app.AppCompatDelegate

class AhirApp : Application() {
    override fun onCreate() {
        super.onCreate()
        applyTheme(this)
    }

    companion object {
        fun applyTheme(c: Context) {
            AppCompatDelegate.setDefaultNightMode(
                when (Prefs.theme(c)) {
                    1 -> AppCompatDelegate.MODE_NIGHT_YES
                    2 -> AppCompatDelegate.MODE_NIGHT_NO
                    else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
                }
            )
        }
    }
}
