package com.ahir.ai

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Screen par click, scroll, type, back/home jaise kaam karta hai. */
class AhirAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: AhirAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    // ---------- global actions ----------
    fun home() = performGlobalAction(GLOBAL_ACTION_HOME)
    fun back() = performGlobalAction(GLOBAL_ACTION_BACK)
    fun recents() = performGlobalAction(GLOBAL_ACTION_RECENTS)
    fun notifications() = performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
    fun screenshot() = performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
    fun lockScreen() = performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)

    // ---------- helpers ----------
    private fun walk(node: AccessibilityNodeInfo?, f: (AccessibilityNodeInfo) -> Boolean): Boolean {
        if (node == null) return false
        if (f(node)) return true
        for (i in 0 until node.childCount) {
            if (walk(node.getChild(i), f)) return true
        }
        return false
    }

    private fun clickNode(n: AccessibilityNodeInfo): Boolean {
        var cur: AccessibilityNodeInfo? = n
        while (cur != null) {
            if (cur.isClickable) return cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            cur = cur.parent
        }
        return false
    }

    fun clickText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val nodes = root.findAccessibilityNodeInfosByText(text)
        for (n in nodes) {
            if (clickNode(n)) return true
        }
        return false
    }

    /** Kisi bhi ek text/description ya view-id (shutter jaisa) par click. */
    fun clickAny(options: List<String>): Boolean {
        for (o in options) {
            if (clickText(o)) return true
        }
        val root = rootInActiveWindow ?: return false
        return walk(root) { n ->
            val id = n.viewIdResourceName ?: ""
            options.any { o -> id.contains(o, ignoreCase = true) } && clickNode(n)
        }
    }

    /** Settings panel mein pehla switch on/off karta hai. */
    fun toggleSwitch(on: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        return walk(root) { n ->
            if (n.isCheckable) {
                if (n.isChecked == on) true else clickNode(n)
            } else false
        }
    }

    fun typeText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val target = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        return target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun scroll(forward: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        val action = if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
        else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        return walk(root) { n -> n.isScrollable && n.performAction(action) }
    }

    fun readScreen(): String {
        val root = rootInActiveWindow ?: return ""
        val sb = StringBuilder()
        walk(root) { n ->
            val t = n.text?.toString()?.trim().orEmpty()
            if (t.isNotEmpty()) sb.append(t).append(". ")
            sb.length > 600
        }
        return sb.toString().take(400)
    }
}
