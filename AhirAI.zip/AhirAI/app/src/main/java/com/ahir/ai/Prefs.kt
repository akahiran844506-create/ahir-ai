package com.ahir.ai

import android.content.Context
import org.json.JSONArray

object Prefs {
    private fun sp(c: Context) =
        c.applicationContext.getSharedPreferences("ahir_prefs", Context.MODE_PRIVATE)

    fun apiKey(c: Context): String = sp(c).getString("api_key", "") ?: ""
    fun setApiKey(c: Context, v: String) = sp(c).edit().putString("api_key", v.trim()).apply()

    fun model(c: Context): String =
        (sp(c).getString("model", "gemini-2.5-flash") ?: "gemini-2.5-flash").ifBlank { "gemini-2.5-flash" }

    fun setModel(c: Context, v: String) = sp(c).edit().putString("model", v.trim()).apply()

    fun voiceFemale(c: Context): Boolean = sp(c).getBoolean("voice_female", true)
    fun setVoiceFemale(c: Context, v: Boolean) = sp(c).edit().putBoolean("voice_female", v).apply()

    /** 0 = system, 1 = dark, 2 = light */
    fun theme(c: Context): Int = sp(c).getInt("theme", 1)
    fun setTheme(c: Context, v: Int) = sp(c).edit().putInt("theme", v).apply()

    fun confirmAll(c: Context): Boolean = sp(c).getBoolean("confirm_all", true)
    fun setConfirmAll(c: Context, v: Boolean) = sp(c).edit().putBoolean("confirm_all", v).apply()

    fun notes(c: Context): List<String> {
        val raw = sp(c).getString("notes", "[]") ?: "[]"
        val arr = try { JSONArray(raw) } catch (e: Exception) { JSONArray() }
        return (0 until arr.length()).map { arr.optString(it) }.filter { it.isNotBlank() }
    }

    fun addNote(c: Context, note: String) {
        val list = notes(c).toMutableList()
        val n = note.trim()
        if (n.isEmpty() || list.contains(n)) return
        list.add(n)
        while (list.size > 100) list.removeAt(0)
        val arr = JSONArray()
        list.forEach { arr.put(it) }
        sp(c).edit().putString("notes", arr.toString()).apply()
    }

    fun clearNotes(c: Context) = sp(c).edit().putString("notes", "[]").apply()
}
