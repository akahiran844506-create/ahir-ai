package com.ahir.ai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var p: Palette
    private lateinit var chat: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var status: TextView
    private lateinit var wakeBtn: TextView
    private var ears: Ears? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        p = Ui.palette(this)
        Speaker.init(this)
        buildUi()
        askPermissions()

        if (Assistant.log.isEmpty()) {
            Assistant.note("Namaste! Main Ahir AI hoon. Mic dabao ya \"Ahir AI\" bolo.")
            if (Prefs.apiKey(this).isBlank()) {
                Assistant.note("Pehle upar Settings (⚙) mein Gemini API key daalo.")
            }
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(p.bg)
            fitsSystemWindows = true
        }

        // ---- top bar ----
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(Ui.dp(this@MainActivity, 16), Ui.dp(this@MainActivity, 12), Ui.dp(this@MainActivity, 8), Ui.dp(this@MainActivity, 12))
            setBackgroundColor(p.surface)
        }
        val titleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleBox.addView(TextView(this).apply {
            text = "AHIR AI"
            textSize = 22f
            setTextColor(p.red)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            letterSpacing = 0.15f
        })
        status = TextView(this).apply {
            text = "Taiyaar"
            textSize = 12f
            setTextColor(p.sub)
        }
        titleBox.addView(status)
        top.addView(titleBox, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        wakeBtn = TextView(this).apply {
            textSize = 13f
            setTextColor(p.text)
            gravity = Gravity.CENTER
            setPadding(Ui.dp(this@MainActivity, 12), Ui.dp(this@MainActivity, 8), Ui.dp(this@MainActivity, 12), Ui.dp(this@MainActivity, 8))
            setOnClickListener { toggleWake() }
        }
        top.addView(wakeBtn)

        val settingsBtn = TextView(this).apply {
            text = "⚙"
            textSize = 24f
            setTextColor(p.text)
            setPadding(Ui.dp(this@MainActivity, 14), Ui.dp(this@MainActivity, 4), Ui.dp(this@MainActivity, 14), Ui.dp(this@MainActivity, 4))
            setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }
        }
        top.addView(settingsBtn)
        root.addView(top)

        // ---- chat ----
        chat = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Ui.dp(this@MainActivity, 12), Ui.dp(this@MainActivity, 12), Ui.dp(this@MainActivity, 12), Ui.dp(this@MainActivity, 12))
        }
        scroll = ScrollView(this).apply { addView(chat) }
        root.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        // ---- bottom bar ----
        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(Ui.dp(this@MainActivity, 12), Ui.dp(this@MainActivity, 8), Ui.dp(this@MainActivity, 12), Ui.dp(this@MainActivity, 12))
            setBackgroundColor(p.surface)
        }
        input = EditText(this).apply {
            hint = "Likhkar bhi bol sakte ho…"
            setHintTextColor(p.sub)
            setTextColor(p.text)
            textSize = 16f
            inputType = InputType.TYPE_CLASS_TEXT
            imeOptions = EditorInfo.IME_ACTION_SEND
            background = Ui.rounded(p.bg, Ui.dp(this@MainActivity, 24).toFloat())
            setPadding(Ui.dp(this@MainActivity, 16), Ui.dp(this@MainActivity, 10), Ui.dp(this@MainActivity, 16), Ui.dp(this@MainActivity, 10))
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_SEND) {
                    sendTyped()
                    true
                } else false
            }
        }
        bottom.addView(input, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        val send = TextView(this).apply {
            text = "➤"
            textSize = 22f
            setTextColor(p.red)
            setPadding(Ui.dp(this@MainActivity, 14), Ui.dp(this@MainActivity, 8), Ui.dp(this@MainActivity, 10), Ui.dp(this@MainActivity, 8))
            setOnClickListener { sendTyped() }
        }
        bottom.addView(send)

        val size = Ui.dp(this, 56)
        val mic = TextView(this).apply {
            text = "🎤"
            textSize = 24f
            gravity = Gravity.CENTER
            background = Ui.circle(p.red)
            setOnClickListener { listenOnce() }
        }
        bottom.addView(mic, LinearLayout.LayoutParams(size, size))
        root.addView(bottom)

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        chat.removeAllViews()
        Assistant.log.forEach { addBubble(it) }
        Assistant.listener = { m -> addBubble(m) }
        refreshWakeBtn()
    }

    override fun onPause() {
        super.onPause()
        Assistant.listener = null
        ears?.destroy()
        ears = null
    }

    private fun addBubble(m: Assistant.Msg) {
        val tv = TextView(this).apply {
            text = m.text
            textSize = 16f
            setTextColor(p.text)
            background = Ui.rounded(if (m.fromUser) p.userBubble else p.botBubble, Ui.dp(this@MainActivity, 16).toFloat())
            setPadding(Ui.dp(this@MainActivity, 14), Ui.dp(this@MainActivity, 10), Ui.dp(this@MainActivity, 14), Ui.dp(this@MainActivity, 10))
            setTextIsSelectable(true)
        }
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            topMargin = Ui.dp(this@MainActivity, 6)
            bottomMargin = Ui.dp(this@MainActivity, 6)
            gravity = if (m.fromUser) Gravity.END else Gravity.START
            if (m.fromUser) marginStart = Ui.dp(this@MainActivity, 48) else marginEnd = Ui.dp(this@MainActivity, 48)
        }
        chat.addView(tv, lp)
        scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    private fun sendTyped() {
        val t = input.text.toString().trim()
        if (t.isEmpty()) return
        input.setText("")
        Assistant.process(this, t) { runOnUiThread { status.text = "Taiyaar" } }
    }

    private fun listenOnce() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            askPermissions()
            return
        }
        Speaker.stop()
        ears?.destroy()
        status.text = "Sun raha hoon…"
        ears = Ears(this,
            { list ->
                runOnUiThread {
                    status.text = "Soch raha hoon…"
                    Assistant.process(this, list[0]) { runOnUiThread { status.text = "Taiyaar" } }
                }
            },
            { _ -> runOnUiThread { status.text = "Samajh nahi aaya, mic dobara dabao" } }
        )
        ears?.start()
    }

    private fun toggleWake() {
        if (WakeService.running) {
            WakeService.stop(this)
            wakeBtn.postDelayed({ refreshWakeBtn() }, 300)
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                askPermissions()
                return
            }
            WakeService.start(this)
            wakeBtn.postDelayed({ refreshWakeBtn() }, 500)
        }
    }

    private fun refreshWakeBtn() {
        val on = WakeService.running
        wakeBtn.text = if (on) "● Sun raha hai" else "○ Wake word band"
        wakeBtn.setTextColor(if (on) p.red else p.sub)
    }

    private fun askPermissions() {
        val list = ArrayList<String>()
        list.add(Manifest.permission.RECORD_AUDIO)
        list.add(Manifest.permission.CALL_PHONE)
        list.add(Manifest.permission.SEND_SMS)
        list.add(Manifest.permission.READ_CONTACTS)
        list.add(Manifest.permission.CAMERA)
        if (Build.VERSION.SDK_INT >= 33) list.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = list.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), 1)
    }
}
