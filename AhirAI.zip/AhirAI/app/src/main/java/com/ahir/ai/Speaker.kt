package com.ahir.ai

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/** Ahir AI ki awaaz (Android ka free Text-to-Speech). */
object Speaker {
    private var tts: TextToSpeech? = null
    @Volatile private var ready = false
    private val waiting = ArrayList<Runnable>()
    private val doneMap = ConcurrentHashMap<String, () -> Unit>()
    private val main = Handler(Looper.getMainLooper())

    fun init(ctx: Context) {
        if (tts != null) return
        val app = ctx.applicationContext
        tts = TextToSpeech(app) { status ->
            ready = status == TextToSpeech.SUCCESS
            if (ready) {
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) {
                        utteranceId?.let { doneMap.remove(it)?.invoke() }
                    }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        utteranceId?.let { doneMap.remove(it)?.invoke() }
                    }
                })
                synchronized(waiting) {
                    waiting.forEach { main.post(it) }
                    waiting.clear()
                }
            } else {
                // TTS nahi chala: jo bhi done-callback atke hain unhe chala do.
                synchronized(waiting) {
                    waiting.forEach { main.post(it) }
                    waiting.clear()
                }
            }
        }
    }

    fun say(ctx: Context, text: String, done: (() -> Unit)? = null) {
        init(ctx)
        val app = ctx.applicationContext
        val job = Runnable {
            val t = tts
            if (!ready || t == null) {
                done?.invoke()
            } else {
                val hindi = text.any { it in 'ऀ'..'ॿ' }
                t.language = if (hindi) Locale("hi", "IN") else Locale("en", "IN")
                val female = Prefs.voiceFemale(app)
                t.setPitch(if (female) 1.25f else 0.75f)
                t.setSpeechRate(1.0f)
                val id = UUID.randomUUID().toString()
                if (done != null) doneMap[id] = done
                val r = t.speak(text, TextToSpeech.QUEUE_ADD, null, id)
                if (r != TextToSpeech.SUCCESS) doneMap.remove(id)?.invoke()
            }
        }
        if (ready) {
            job.run()
        } else {
            synchronized(waiting) { waiting.add(job) }
        }
    }

    fun stop() {
        tts?.stop()
    }
}
