package com.ahir.ai

import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.GradientDrawable

/** Dark / light red theme ke rang. */
class Palette(
    val bg: Int,
    val surface: Int,
    val text: Int,
    val sub: Int,
    val red: Int,
    val userBubble: Int,
    val botBubble: Int
)

object Ui {
    fun palette(c: Context): Palette {
        val night = (c.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        return if (night) {
            Palette(
                bg = Color.parseColor("#0B0B0F"),
                surface = Color.parseColor("#17171F"),
                text = Color.parseColor("#F2F2F5"),
                sub = Color.parseColor("#9A9AA6"),
                red = Color.parseColor("#FF2D3B"),
                userBubble = Color.parseColor("#8F0F1A"),
                botBubble = Color.parseColor("#1E1E28")
            )
        } else {
            Palette(
                bg = Color.parseColor("#FFFFFF"),
                surface = Color.parseColor("#F3F3F6"),
                text = Color.parseColor("#111114"),
                sub = Color.parseColor("#6B6B76"),
                red = Color.parseColor("#D90012"),
                userBubble = Color.parseColor("#FFD9DC"),
                botBubble = Color.parseColor("#EDEDF1")
            )
        }
    }

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density).toInt()

    fun rounded(color: Int, radiusPx: Float): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radiusPx
        }

    fun circle(color: Int): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(color)
        }
}
