package com.ahir.ai

import android.content.Context
import android.os.Handler
import android.os.Looper
import java.util.concurrent.CopyOnWriteArrayList

/** Ahir AI ka dimaag-aur-haath ka beech ka manager: sunna -> samajhna -> poochna -> karna. */
object Assistant {

    data class Msg(val fromUser: Boolean, val text: String)

    val log = CopyOnWriteArrayList<Msg>()

    @Volatile
    var listener: ((Msg) -> Unit)? = null

    /** true jab Ahir AI user ke agle jawab (haan/nahi ya sawal ka jawab) ka intezaar kar raha hai. */
    @Volatile
    var awaiting = false

    @Volatile
    private var pending: Gemini.Plan? = null

    private val main = Handler(Looper.getMainLooper())

    private val noWords = listOf(
        "nahi", "nahin", "nhi", "no", "mat", "ruko", "cancel", "stop",
        "नहीं", "नही", "मत", "रुको", "रहने दो", "rehne do", "rehne de"
    )
    private val yesWords = listOf(
        "haan", "han", "haa", "ha", "yes", "yeah", "ok", "okay", "theek", "thik", "pakka",
        "kar do", "kardo", "karo", "kar de", "sure", "ji", "jee",
        "हाँ", "हां", "हा", "जी", "ठीक", "बिल्कुल", "कर दो", "करो", "पक्का"
    )

    private fun tokens(s: String): List<String> =
        s.lowercase().split(Regex("[\\s,.!?।]+")).filter { it.isNotEmpty() }

    private fun matches(text: String, words: List<String>): Boolean {
        val t = tokens(text)
        val joined = t.joinToString(" ")
        return words.any { w -> if (w.contains(" ")) joined.contains(w) else t.contains(w) }
    }

    private fun add(m: Msg) {
        log.add(m)
        while (log.size > 100) log.removeAt(0)
        listener?.let { l -> main.post { l(m) } }
    }

    /** Sirf screen par dikhao (bolo mat). */
    fun note(text: String) = add(Msg(false, text))

    fun say(ctx: Context, text: String, done: (() -> Unit)? = null) {
        add(Msg(false, text))
        Speaker.say(ctx, text, done)
    }

    fun cancelPending() {
        pending = null
        awaiting = false
    }

    fun process(ctx: Context, text: String, onFinished: () -> Unit) {
        val app = ctx.applicationContext
        add(Msg(true, text))

        val p = pending
        if (p != null) {
            pending = null
            awaiting = false
            when {
                matches(text, noWords) -> {
                    say(app, "Theek hai, cancel kar diya.", onFinished)
                    return
                }
                matches(text, yesWords) -> {
                    runPlan(app, p, onFinished)
                    return
                }
                // warna ye ek naya command hai, neeche chalega
            }
        }

        awaiting = false
        Thread {
            val plan = Gemini.ask(app, text)
            if (plan.remember.isNotBlank()) Prefs.addNote(app, plan.remember)
            when {
                plan.ask.isNotBlank() -> {
                    awaiting = true
                    say(app, plan.ask, onFinished)
                }
                plan.actions.isEmpty() -> say(app, plan.reply.ifBlank { "Samajh nahi paya, dobara bolo." }, onFinished)
                !Prefs.confirmAll(app) -> runPlan(app, plan, onFinished)
                else -> {
                    pending = plan
                    awaiting = true
                    say(app, plan.reply + " Pakka karun? Haan ya nahi bolo.", onFinished)
                }
            }
        }.start()
    }

    private fun runPlan(app: Context, plan: Gemini.Plan, onFinished: () -> Unit) {
        Thread {
            val results = ArrayList<String>()
            for ((index, action) in plan.actions.withIndex()) {
                if (index > 0) Thread.sleep(1800)
                results.add(Actions.run(app, action))
            }
            say(app, results.joinToString(" "), onFinished)
        }.start()
    }
}
