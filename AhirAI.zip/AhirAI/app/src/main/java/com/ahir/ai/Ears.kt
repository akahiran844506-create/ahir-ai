package com.ahir.ai

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/** Awaaz sunne wala (Android ka SpeechRecognizer). Ek baar sunta hai, phir result deta hai. */
class Ears(
    ctx: Context,
    private val onText: (List<String>) -> Unit,
    private val onFail: (Int) -> Unit
) {
    private val app = ctx.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private var rec: SpeechRecognizer? = null

    fun start() {
        main.post {
            try {
                if (!SpeechRecognizer.isRecognitionAvailable(app)) {
                    onFail(-1)
                    return@post
                }
                rec?.destroy()
                val r = SpeechRecognizer.createSpeechRecognizer(app)
                rec = r
                r.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {}
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() {}
                    override fun onPartialResults(partialResults: Bundle?) {}
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                    override fun onError(error: Int) {
                        onFail(error)
                    }

                    override fun onResults(results: Bundle?) {
                        val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            ?.filter { it.isNotBlank() }
                        if (list.isNullOrEmpty()) onFail(SpeechRecognizer.ERROR_NO_MATCH) else onText(list)
                    }
                })
                val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                    putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, app.packageName)
                }
                r.startListening(i)
            } catch (e: Exception) {
                onFail(-2)
            }
        }
    }

    fun stop() {
        main.post { try { rec?.cancel() } catch (_: Exception) {} }
    }

    fun destroy() {
        main.post {
            try { rec?.destroy() } catch (_: Exception) {}
            rec = null
        }
    }
}
