package com.ahir.ai

import android.Manifest
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.telephony.SmsManager
import androidx.core.content.ContextCompat
import org.json.JSONObject

/** Phone par asli kaam yahan hote hain. Har function ek chhota result message lautata hai. */
object Actions {

    private val main = Handler(Looper.getMainLooper())

    private fun has(ctx: Context, perm: String) =
        ContextCompat.checkSelfPermission(ctx, perm) == PackageManager.PERMISSION_GRANTED

    private fun launch(ctx: Context, intent: Intent): Boolean {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        // Accessibility service se activity kholna background mein bhi chalta hai.
        val starter: Context = AhirAccessibilityService.instance ?: ctx
        return try {
            starter.startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun later(ms: Long, block: () -> Unit) {
        main.postDelayed({ block() }, ms)
    }

    private fun acc() = AhirAccessibilityService.instance

    private const val NEED_ACC = "Accessibility service chalu nahi hai. Settings se on karo."

    // ---------- contacts ----------
    private fun findNumber(ctx: Context, name: String): String? {
        if (name.isBlank() || !has(ctx, Manifest.permission.READ_CONTACTS)) return null
        val c = ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
            arrayOf("%$name%"),
            null
        )
        c?.use {
            if (it.moveToFirst()) return it.getString(0)
        }
        return null
    }

    private fun target(ctx: Context, a: JSONObject): String? {
        val direct = a.optString("number").filter { it.isDigit() || it == '+' }
        if (direct.length >= 5) return direct
        val found = findNumber(ctx, a.optString("name")) ?: return null
        return found.filter { it.isDigit() || it == '+' }
    }

    // ---------- main entry ----------
    fun run(ctx: Context, a: JSONObject): String {
        return try {
            when (val t = a.optString("type")) {
                "call" -> call(ctx, a)
                "sms" -> sms(ctx, a)
                "whatsapp" -> whatsapp(ctx, a)
                "open_app" -> openApp(ctx, a.optString("app"))
                "music" -> music(ctx, a.optString("query"))
                "alarm" -> alarm(ctx, a)
                "timer" -> timer(ctx, a)
                "flashlight" -> flashlight(ctx, a.optBoolean("on", true))
                "wifi" -> panel(ctx, a.optBoolean("on", true), true)
                "bluetooth" -> panel(ctx, a.optBoolean("on", true), false)
                "volume" -> volume(ctx, a)
                "brightness" -> brightness(ctx, a.optInt("level", 50))
                "camera" -> camera(ctx, false)
                "take_photo" -> camera(ctx, true)
                "navigate" -> navigate(ctx, a.optString("place"))
                "web_search" -> webSearch(ctx, a.optString("query"))
                "go_home" -> accDo { it.home() }.let { if (it) "Home par aa gaya." else NEED_ACC }
                "go_back" -> accDo { it.back() }.let { if (it) "Peeche aa gaya." else NEED_ACC }
                "recents" -> accDo { it.recents() }.let { if (it) "Recent apps khol diye." else NEED_ACC }
                "notifications" -> accDo { it.notifications() }.let { if (it) "Notifications khol diye." else NEED_ACC }
                "screenshot" -> accDo { it.screenshot() }.let { if (it) "Screenshot le liya." else NEED_ACC }
                "lock_screen" -> accDo { it.lockScreen() }.let { if (it) "Phone lock kar diya." else NEED_ACC }
                "scroll_down" -> accResult("Neeche scroll kiya.", "Scroll nahi ho paya.") { it.scroll(true) }
                "scroll_up" -> accResult("Upar scroll kiya.", "Scroll nahi ho paya.") { it.scroll(false) }
                "click_text" -> {
                    val txt = a.optString("text")
                    accResult("\"$txt\" par click kiya.", "\"$txt\" screen par nahi mila.") { it.clickText(txt) }
                }
                "type_text" -> accResult("Likh diya.", "Likhne ke liye koi box select nahi hai.") { it.typeText(a.optString("text")) }
                "read_screen" -> {
                    val s = acc() ?: return NEED_ACC
                    val txt = s.readScreen()
                    if (txt.isBlank()) "Screen par padhne layak kuch nahi mila." else txt
                }
                else -> "Ye kaam abhi mujhe nahi aata: $t"
            }
        } catch (e: Exception) {
            "Kaam karte waqt dikkat aayi: ${e.message}"
        }
    }

    private fun accDo(f: (AhirAccessibilityService) -> Boolean): Boolean {
        val s = acc() ?: return false
        return f(s)
    }

    private fun accResult(ok: String, fail: String, f: (AhirAccessibilityService) -> Boolean): String {
        val s = acc() ?: return NEED_ACC
        return if (f(s)) ok else fail
    }

    // ---------- calls & messages ----------
    private fun call(ctx: Context, a: JSONObject): String {
        val num = target(ctx, a) ?: return "\"${a.optString("name")}\" ka number nahi mila."
        val action = if (has(ctx, Manifest.permission.CALL_PHONE)) Intent.ACTION_CALL else Intent.ACTION_DIAL
        val ok = launch(ctx, Intent(action, Uri.parse("tel:" + Uri.encode(num))))
        return if (ok) "Call laga raha hoon." else "Call nahi lag paya."
    }

    private fun sms(ctx: Context, a: JSONObject): String {
        val num = target(ctx, a) ?: return "\"${a.optString("name")}\" ka number nahi mila."
        val text = a.optString("text")
        if (!has(ctx, Manifest.permission.SEND_SMS)) {
            val i = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$num")).putExtra("sms_body", text)
            return if (launch(ctx, i)) "SMS permission nahi hai, isliye message khol diya, bas send dabao." else "SMS nahi ho paya."
        }
        val sm = ctx.getSystemService(SmsManager::class.java)
        sm.sendMultipartTextMessage(num, null, sm.divideMessage(text), null, null)
        return "SMS bhej diya."
    }

    private fun whatsapp(ctx: Context, a: JSONObject): String {
        var num = target(ctx, a) ?: return "\"${a.optString("name")}\" ka number nahi mila."
        num = num.filter { it.isDigit() }
        if (num.length == 10) num = "91$num"
        val uri = Uri.parse("https://wa.me/$num?text=" + Uri.encode(a.optString("text")))
        var ok = launch(ctx, Intent(Intent.ACTION_VIEW, uri).setPackage("com.whatsapp"))
        if (!ok) ok = launch(ctx, Intent(Intent.ACTION_VIEW, uri))
        if (!ok) return "WhatsApp nahi khul paya."
        later(4000) { acc()?.clickAny(listOf("Send", "भेजें", "send")) }
        return "WhatsApp khola aur Send dabane ki koshish ki."
    }

    // ---------- apps & media ----------
    private fun openApp(ctx: Context, name: String): String {
        if (name.isBlank()) return "Kaun sa app kholna hai?"
        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(main, 0)
        val q = name.lowercase().trim()
        val exact = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == q }
        val partial = apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
        val match = exact ?: partial ?: return "\"$name\" naam ka app nahi mila."
        val i = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
            ?: return "\"$name\" khul nahi paya."
        return if (launch(ctx, i)) "${match.loadLabel(pm)} khol diya." else "\"$name\" khul nahi paya."
    }

    private fun music(ctx: Context, q: String): String {
        if (q.isBlank()) return "Kaun sa gaana chalaun?"
        val play = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
            .putExtra(SearchManager.QUERY, q)
            .putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
        if (play.resolveActivity(ctx.packageManager) != null && launch(ctx, play)) {
            return "\"$q\" chala raha hoon."
        }
        val yt = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q)))
        return if (launch(ctx, yt)) {
            later(4500) { acc()?.clickAny(listOf("Play", "चलाएं")) }
            "YouTube par \"$q\" khola."
        } else "Gaana nahi chal paya."
    }

    // ---------- clock ----------
    private fun alarm(ctx: Context, a: JSONObject): String {
        val h = a.optInt("hour", -1)
        val m = a.optInt("minute", 0)
        if (h !in 0..23) return "Alarm kitne baje ka lagana hai?"
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, h)
            .putExtra(AlarmClock.EXTRA_MINUTES, m)
            .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", "Ahir AI"))
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        return if (launch(ctx, i)) "Alarm lag gaya: %02d:%02d.".format(h, m) else "Alarm nahi lag paya."
    }

    private fun timer(ctx: Context, a: JSONObject): String {
        val s = a.optInt("seconds", 0)
        if (s <= 0) return "Timer kitni der ka lagana hai?"
        val i = Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, s)
            .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", "Ahir AI"))
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        return if (launch(ctx, i)) "Timer lag gaya." else "Timer nahi lag paya."
    }

    // ---------- device controls ----------
    private fun flashlight(ctx: Context, on: Boolean): String {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return "Is phone mein flashlight nahi mili."
        cm.setTorchMode(id, on)
        return if (on) "Flashlight on kar di." else "Flashlight band kar di."
    }

    private fun panel(ctx: Context, on: Boolean, wifi: Boolean): String {
        val intent = if (wifi) Intent(Settings.Panel.ACTION_WIFI) else Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
        if (!launch(ctx, intent)) return "Settings nahi khul paya."
        val name = if (wifi) "WiFi" else "Bluetooth"
        if (acc() == null) return "$name ka panel khol diya. Accessibility on ho to main khud switch dabaunga."
        later(1800) { acc()?.toggleSwitch(on) }
        return "$name ${if (on) "on" else "off"} kar raha hoon."
    }

    private fun volume(ctx: Context, a: JSONObject): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val level = a.optInt("level", -1)
        if (level in 0..100) {
            am.setStreamVolume(AudioManager.STREAM_MUSIC, level * max / 100, AudioManager.FLAG_SHOW_UI)
            return "Volume $level% kar diya."
        }
        return when (a.optString("direction")) {
            "up" -> { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI); "Volume badha diya." }
            "down" -> { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI); "Volume kam kar diya." }
            "mute" -> { am.setStreamVolume(AudioManager.STREAM_MUSIC, 0, AudioManager.FLAG_SHOW_UI); "Awaaz band kar di." }
            else -> "Volume kitna karna hai?"
        }
    }

    private fun brightness(ctx: Context, level: Int): String {
        if (!Settings.System.canWrite(ctx)) {
            launch(ctx, Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + ctx.packageName)))
            return "Brightness ke liye permission chahiye. Settings khol di, Ahir AI ko allow karo."
        }
        val v = level.coerceIn(0, 100) * 255 / 100
        Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
        Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, v)
        return "Brightness $level% kar di."
    }

    private fun camera(ctx: Context, shoot: Boolean): String {
        if (!launch(ctx, Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))) return "Camera nahi khul paya."
        if (!shoot) return "Camera khol diya."
        if (acc() == null) return "Camera khol diya. Photo ke liye Accessibility on karo."
        later(3000) { acc()?.clickAny(listOf("shutter", "Shutter", "Take photo", "Capture", "फ़ोटो")) }
        return "Photo kheench raha hoon."
    }

    // ---------- web & maps ----------
    private fun navigate(ctx: Context, place: String): String {
        if (place.isBlank()) return "Kahan jaana hai?"
        val maps = Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(place)))
            .setPackage("com.google.android.apps.maps")
        if (launch(ctx, maps)) return "$place ka rasta khol diya."
        val geo = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(place)))
        return if (launch(ctx, geo)) "$place map par khol diya." else "Map nahi khul paya."
    }

    private fun webSearch(ctx: Context, q: String): String {
        if (q.isBlank()) return "Kya search karun?"
        val i = Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, q)
        if (launch(ctx, i)) return "\"$q\" search kar raha hoon."
        val web = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q)))
        return if (launch(ctx, web)) "\"$q\" search kar raha hoon." else "Search nahi ho paya."
    }
}
