package com.ahir.ai

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {

    private lateinit var p: Palette
    private lateinit var keyEt: EditText
    private lateinit var modelEt: EditText
    private lateinit var voiceGroup: RadioGroup
    private lateinit var themeGroup: RadioGroup
    private lateinit var confirmSw: Switch
    private lateinit var notesTv: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        p = Ui.palette(this)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Ui.dp(this@SettingsActivity, 18), Ui.dp(this@SettingsActivity, 18), Ui.dp(this@SettingsActivity, 18), Ui.dp(this@SettingsActivity, 40))
        }
        val sv = ScrollView(this).apply {
            setBackgroundColor(p.bg)
            fitsSystemWindows = true
            addView(col)
        }

        col.addView(title("Settings"))

        // ---- Gemini ----
        col.addView(label("Gemini API key (free)"))
        keyEt = field(Prefs.apiKey(this), "AIza…")
        keyEt.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        col.addView(keyEt)
        col.addView(button("Free key banao (aistudio.google.com)") {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/apikey")))
        })

        col.addView(label("Gemini model ka naam"))
        modelEt = field(Prefs.model(this), "gemini-2.5-flash")
        col.addView(modelEt)

        // ---- Voice ----
        col.addView(label("Ahir AI ki awaaz"))
        voiceGroup = RadioGroup(this).apply {
            orientation = RadioGroup.HORIZONTAL
            addView(radio("Ladki", 1))
            addView(radio("Ladka", 2))
            check(if (Prefs.voiceFemale(this@SettingsActivity)) 1 else 2)
        }
        col.addView(voiceGroup)
        col.addView(button("Awaaz test karo") {
            saveAll(false)
            Speaker.say(this, "Namaste, main Ahir AI hoon.")
        })

        // ---- Theme ----
        col.addView(label("Theme"))
        themeGroup = RadioGroup(this).apply {
            orientation = RadioGroup.HORIZONTAL
            addView(radio("Dark", 1))
            addView(radio("Light", 2))
            addView(radio("System", 0))
            check(Prefs.theme(this@SettingsActivity))
        }
        col.addView(themeGroup)

        // ---- Safety ----
        confirmSw = Switch(this).apply {
            text = "Har kaam se pehle puchho (Pakka karun?)"
            setTextColor(p.text)
            isChecked = Prefs.confirmAll(this@SettingsActivity)
        }
        col.addView(confirmSw, spaced())

        // ---- Permissions ----
        col.addView(label("Zaroori permissions (ek baar de do)"))
        col.addView(button("1) Accessibility service on karo") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        col.addView(button("2) Display over other apps allow karo") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        col.addView(button("3) Brightness badalne ki permission") {
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
        })
        col.addView(button("4) Battery restriction hatao (lock screen par chalne ke liye)") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })

        // ---- Memory ----
        col.addView(label("Ahir AI ko jo yaad hai"))
        notesTv = TextView(this).apply {
            setTextColor(p.sub)
            textSize = 14f
        }
        col.addView(notesTv)
        refreshNotes()
        col.addView(button("Yaadasht saaf karo") {
            Prefs.clearNotes(this)
            refreshNotes()
        })

        // ---- Save ----
        val save = button("SAVE") { saveAll(true) }
        save.background = Ui.rounded(p.red, Ui.dp(this, 12).toFloat())
        save.setTextColor(0xFFFFFFFF.toInt())
        col.addView(save)

        setContentView(sv)
    }

    private fun refreshNotes() {
        val n = Prefs.notes(this)
        notesTv.text = if (n.isEmpty()) "Abhi kuch nahi. Bolo: \"yaad rakho, mummy ka naam Sunita hai\"."
        else n.joinToString("\n") { "• $it" }
    }

    private fun saveAll(finishAfter: Boolean) {
        Prefs.setApiKey(this, keyEt.text.toString())
        Prefs.setModel(this, modelEt.text.toString())
        Prefs.setVoiceFemale(this, voiceGroup.checkedRadioButtonId == 1)
        Prefs.setConfirmAll(this, confirmSw.isChecked)
        val oldTheme = Prefs.theme(this)
        val newTheme = themeGroup.checkedRadioButtonId
        Prefs.setTheme(this, newTheme)
        if (finishAfter) {
            Toast.makeText(this, "Save ho gaya", Toast.LENGTH_SHORT).show()
            if (oldTheme != newTheme) AhirApp.applyTheme(this)
            finish()
        }
    }

    // ---------- small view helpers ----------
    private fun spaced(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            topMargin = Ui.dp(this@SettingsActivity, 12)
        }

    private fun title(t: String) = TextView(this).apply {
        text = t
        textSize = 26f
        setTextColor(p.red)
        typeface = android.graphics.Typeface.DEFAULT_BOLD
    }

    private fun label(t: String): TextView = TextView(this).apply {
        text = t
        textSize = 14f
        setTextColor(p.text)
        typeface = android.graphics.Typeface.DEFAULT_BOLD
        layoutParams = spaced().apply { topMargin = Ui.dp(this@SettingsActivity, 22) }
    }

    private fun field(value: String, hint: String) = EditText(this).apply {
        setText(value)
        this.hint = hint
        setTextColor(p.text)
        setHintTextColor(p.sub)
        setSingleLine(true)
        background = Ui.rounded(p.surface, Ui.dp(this@SettingsActivity, 10).toFloat())
        setPadding(Ui.dp(this@SettingsActivity, 14), Ui.dp(this@SettingsActivity, 12), Ui.dp(this@SettingsActivity, 14), Ui.dp(this@SettingsActivity, 12))
        layoutParams = spaced()
    }

    private fun radio(t: String, id: Int) = RadioButton(this).apply {
        text = t
        this.id = id
        setTextColor(p.text)
    }

    private fun button(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t
        isAllCaps = false
        setTextColor(p.text)
        background = Ui.rounded(p.surface, Ui.dp(this@SettingsActivity, 12).toFloat())
        layoutParams = spaced()
        setOnClickListener { onClick() }
    }
}
