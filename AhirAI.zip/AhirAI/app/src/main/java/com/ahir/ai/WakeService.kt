package com.ahir.ai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat

/** "Ahir AI" bolne ka intezaar karta hai (screen band ho tab bhi). */
class WakeService : Service() {

    companion object {
        private const val CHANNEL = "ahir_wake"
        private const val ACTION_STOP = "com.ahir.ai.STOP"

        @Volatile
        var running = false

        private val WAKE = Regex(
            "(ahir|aheer|ahiir|अहीर|अहिर|आहिर)\\s*(ai|a\\.i\\.|a i|ए\\s?आई|एआई|ऐ\\s?आई)?",
            RegexOption.IGNORE_CASE
        )

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, WakeService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, WakeService::class.java))
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private var ears: Ears? = null
    private var followUp = false
    private var failCount = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Ahir AI sun raha hai", NotificationManager.IMPORTANCE_LOW)
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, WakeService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val openIntent = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notif: Notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Ahir AI")
            .setContentText("\"Ahir AI\" bolo, main sun raha hoon")
            .setContentIntent(openIntent)
            .addAction(0, "Band karo", stopIntent)
            .setOngoing(true)
            .build()
        try {
            ServiceCompat.startForeground(this, 1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } catch (e: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }

        Speaker.init(this)
        if (!running) {
            running = true
            ears = Ears(this, { list -> onHeard(list) }, { code -> onFail(code) })
            listenSoon(300)
        }
        return START_STICKY
    }

    private fun listenSoon(delayMs: Long) {
        handler.postDelayed({
            if (running) ears?.start()
        }, delayMs)
    }

    private fun onHeard(list: List<String>) {
        if (followUp) {
            followUp = false
            failCount = 0
            handle(list[0])
            return
        }
        // Wake word saare alternatives mein dhundho
        var command: String? = null
        for (s in list) {
            val m = WAKE.find(s)
            if (m != null) {
                command = s.substring(m.range.last + 1).trim()
                break
            }
        }
        when {
            command == null -> listenSoon(200)
            command.isBlank() -> {
                Assistant.say(this, "Ji, boliye.") {
                    followUp = true
                    failCount = 0
                    listenSoon(100)
                }
            }
            else -> handle(command)
        }
    }

    private fun handle(command: String) {
        Assistant.process(this, command) {
            followUp = Assistant.awaiting
            failCount = 0
            listenSoon(300)
        }
    }

    private fun onFail(code: Int) {
        if (code == -1 || code == -2 || code == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
            Assistant.note("Awaaz sunne wali service nahi chal paayi. Mic permission aur Google voice app check karo.")
            handler.post { stopSelf() }
            return
        }
        if (followUp) {
            failCount++
            if (failCount >= 2) {
                followUp = false
                Assistant.cancelPending()
            }
        }
        val wait = if (code == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1500L else 500L
        listenSoon(wait)
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        ears?.destroy()
        ears = null
        super.onDestroy()
    }
}
