package com.ahir.ai

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Ahir AI ka dimaag: Google Gemini (free API key). */
object Gemini {

    data class Plan(
        val reply: String,
        val ask: String,
        val actions: List<JSONObject>,
        val remember: String
    )

    private val history = ArrayList<Pair<String, String>>() // role ("user"/"model"), text

    private fun systemPrompt(ctx: Context): String {
        val now = SimpleDateFormat("EEEE, dd MMM yyyy, HH:mm", Locale.ENGLISH).format(Date())
        val notes = Prefs.notes(ctx)
        val memory = if (notes.isEmpty()) "(abhi kuch yaad nahi)" else notes.joinToString("\n") { "- $it" }
        return """
Tum "Ahir AI" ho, ek personal voice assistant jo user ke Android phone ko control karta hai.
User Hinglish (Hindi + English mix) mein baat karta hai. Tum bhi chhota, saaf, dostana Hinglish (Roman script) mein jawab do. Maximum 2 chhote vakya.
Abhi ka samay: $now

User ne tumhe ye baatein yaad rakhne ko boli hain:
$memory

Tumhara output HAMESHA sirf ek JSON object ho, aur kuch nahi:
{"reply": "...", "ask": "", "actions": [], "remember": ""}

Niyam:
- Agar user sirf sawal puchh raha hai ya baat kar raha hai, to "actions" khaali rakho aur "reply" mein jawab do.
- Agar phone par koi kaam karwana hai, to "actions" mein daalo, aur "reply" mein chhota sa batao ki tum kya karne wale ho (jaise "Mummy ko call lagata hoon."). Confirmation app khud puchhega.
- Agar kaam ke liye zaroori jaankari kam hai ya tum atak gaye (kis contact ko? kitne baje? kaun sa app?), to "actions" khaali rakho aur "ask" mein user se ek chhota sawal puchho. Andaza mat lagao.
- Agar user koi cheez yaad rakhne ko bole (naam, nickname, pasand, aadat), to "remember" mein ek chhoti line likho. Warna khaali.
- Contact ka naam jaisa user bole waisa "name" mein do (nickname ho to yaad ki hui baatein dekho). Number pata ho to "number" mein do.
- Hindi app naam ho to English mein badlo (jaise "kailkulator" -> "Calculator").

Actions ki list (har action: {"type": ..., ...}):
- {"type":"call","name":"","number":""}
- {"type":"sms","name":"","number":"","text":""}
- {"type":"whatsapp","name":"","number":"","text":""}
- {"type":"open_app","app":"app ka naam"}
- {"type":"music","query":"gaane ya artist ka naam"}  (music/YouTube chalane ke liye)
- {"type":"alarm","hour":0-23,"minute":0-59,"label":""}
- {"type":"timer","seconds":number,"label":""}
- {"type":"flashlight","on":true/false}
- {"type":"wifi","on":true/false}
- {"type":"bluetooth","on":true/false}
- {"type":"volume","level":0-100}  ya  {"type":"volume","direction":"up"/"down"/"mute"}
- {"type":"brightness","level":0-100}
- {"type":"camera"}  (camera kholna)
- {"type":"take_photo"}  (camera kholke photo khinchna)
- {"type":"navigate","place":""}
- {"type":"web_search","query":""}
- {"type":"go_home"}, {"type":"go_back"}, {"type":"recents"}, {"type":"notifications"}, {"type":"screenshot"}, {"type":"lock_screen"}
- {"type":"scroll_down"}, {"type":"scroll_up"}
- {"type":"click_text","text":"screen par dikhne wala text"}
- {"type":"type_text","text":""}
- {"type":"read_screen"}  (screen par likha padhkar sunana)
Ek se zyada kaam ho to actions ko order mein likho.
""".trimIndent()
    }

    fun ask(ctx: Context, userText: String): Plan {
        val key = Prefs.apiKey(ctx)
        if (key.isBlank()) {
            return Plan("Pehle Settings mein jaake Gemini API key daalo.", "", emptyList(), "")
        }
        try {
            val body = JSONObject()
            body.put(
                "systemInstruction",
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt(ctx))))
            )
            val contents = JSONArray()
            val recent = history.takeLast(12)
            for ((role, text) in recent) {
                contents.put(
                    JSONObject().put("role", role)
                        .put("parts", JSONArray().put(JSONObject().put("text", text)))
                )
            }
            contents.put(
                JSONObject().put("role", "user")
                    .put("parts", JSONArray().put(JSONObject().put("text", userText)))
            )
            body.put("contents", contents)
            body.put(
                "generationConfig",
                JSONObject().put("responseMimeType", "application/json").put("temperature", 0.3)
            )

            val url = URL("https://generativelanguage.googleapis.com/v1beta/models/${Prefs.model(ctx)}:generateContent")
            val conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.connectTimeout = 15000
            conn.readTimeout = 40000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("x-goog-api-key", key)
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            conn.disconnect()

            if (code == 429) {
                return Plan("Gemini ki free limit abhi khatam hai. Thodi der baad try karo.", "", emptyList(), "")
            }
            if (code == 400 || code == 401 || code == 403) {
                return Plan("Gemini API key ya model ka naam galat lag raha hai. Settings check karo.", "", emptyList(), "")
            }
            if (code !in 200..299) {
                return Plan("Gemini se jawab nahi mila (error $code).", "", emptyList(), "")
            }

            val root = JSONObject(text)
            val out = root.getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
            val cleaned = out.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
            val j = JSONObject(cleaned)

            val reply = j.optString("reply", "")
            val ask = j.optString("ask", "")
            val remember = j.optString("remember", "")
            val arr = j.optJSONArray("actions") ?: JSONArray()
            val actions = (0 until arr.length()).mapNotNull { arr.optJSONObject(it) }

            history.add("user" to userText)
            history.add("model" to (if (ask.isNotBlank()) ask else reply))
            while (history.size > 24) history.removeAt(0)

            return Plan(reply, ask, actions, remember)
        } catch (e: java.io.IOException) {
            return Plan("Internet nahi chal raha lagta hai.", "", emptyList(), "")
        } catch (e: Exception) {
            return Plan("Mujhe jawab samajhne mein dikkat hui. Dobara bolo.", "", emptyList(), "")
        }
    }
}
