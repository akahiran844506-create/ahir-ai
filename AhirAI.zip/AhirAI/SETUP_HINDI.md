# Ahir AI: Phone se App Banane aur Install karne ka tareeka

Computer ki zaroorat nahi. Sab kuch phone ke browser se hoga.

## Part 1: GitHub account (free)
1. Browser mein `github.com` kholo, **Sign up** dabao.
2. Email, password, username daalo, email verify karo.

## Part 2: Repository banao
1. Login ke baad upar **+** dabao, phir **New repository**.
2. Naam likho: `ahir-ai`. **Public** ya **Private**, dono chalega.
3. **Create repository** dabao.

## Part 3: Do cheezein upload karo
**(a) AhirAI.zip upload karo**
1. Repository mein **uploading an existing file** (ya Add file > Upload files) dabao.
2. `AhirAI.zip` file chuno (jo maine di hai) aur upload karo.
3. Neeche **Commit changes** dabao.

**(b) Build file banao**
1. **Add file > Create new file** dabao.
2. Naam wali jagah ye likho (slash bhi likhna): `.github/workflows/build.yml`
3. File ke andar wo text paste karo jo is zip ke andar `.github/workflows/build.yml` mein hai (ya chat mein diya gaya).
4. **Commit changes** dabao.

## Part 4: APK banne ka intezaar
1. Repository mein upar **Actions** tab kholo.
2. "Build APK" chalta dikhega. 5 se 8 minute lagte hain. Hara tick aaye to ready.
3. Us run par dabao, neeche **Artifacts** mein `AhirAI-APK` milega. Dabake download karo (zip aayegi).
4. Download hui zip ko phone ke Files app se **Extract** karo. Andar `app-debug.apk` hai.
5. Agar laal cross aaye to us par dabao, error ka text copy karke mujhe bhej do. Main thik kar dunga.

## Part 5: Install
1. `app-debug.apk` dabao. "Install unknown apps" aaye to allow karo.
2. Install ho jaaye to **Ahir AI** kholo. Saari permissions (mic, call, SMS, contacts) allow karo.

## Part 6: Free Gemini key lo
1. Browser mein `aistudio.google.com/apikey` kholo, Google se login karo.
2. **Create API key** dabao, key copy karo (`AIza...` se shuru hoti hai).
3. Ahir AI mein **⚙ Settings** > key paste karo > **SAVE**.

## Part 7: Phone control permissions (Settings ⚙ mein 4 buttons)
1. **Accessibility** > "Ahir AI" chuno > On karo. (Click, scroll, back, home ke liye)
2. **Display over other apps** > allow karo. (Background se apps kholne ke liye)
3. **Brightness** permission allow karo.
4. **Battery restriction hatao**, taaki lock screen par bhi sunta rahe.

## Istemal
- Mic dabao ya upar **Wake word** button dabake "Ahir AI" bolo.
- Misaal: "Ahir AI, flashlight on karo", "Mummy ko call karo", "Raat 10 baje ka alarm lagao", "Yaad rakho mere bhai ka naam Rohit hai".
- Har kaam se pehle wo puchega "Pakka karun?". "Haan" ya "nahi" bolo.

## Zaroori baatein (Android ke rules)
- Wake word sunne ke liye Google ki speech service use hoti hai, isliye internet chahiye aur beep aa sakti hai.
- Phone lock hone par kuch kaam (apps kholna, tap karna) Android rokta hai. Phone unlock hone par hi poore chalte hain.
- WiFi/Bluetooth/Camera shutter jaise kaam Accessibility se screen par dabake hote hain, kabhi-kabhi fail ho sakte hain.
- Gemini free limit khatam ho jaaye to thodi der baad try karo.
